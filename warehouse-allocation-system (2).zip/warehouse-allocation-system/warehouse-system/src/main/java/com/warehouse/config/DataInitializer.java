package com.warehouse.config;

import com.warehouse.model.*;
import com.warehouse.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataInitializer {

    private final WarehouseRepository warehouseRepository;
    private final ProductRepository productRepository;
    private final WarehouseInventoryRepository inventoryRepository;

    @Bean
    @Profile("!test")
    public CommandLineRunner initData() {
        return args -> {
            log.info("Initializing sample data...");

            // Create warehouses
            Warehouse w1 = warehouseRepository.save(Warehouse.builder()
                    .name("North Hub").location("New York").capacity(1000)
                    .status(Warehouse.WarehouseStatus.ACTIVE).build());
            Warehouse w2 = warehouseRepository.save(Warehouse.builder()
                    .name("South Hub").location("Miami").capacity(800)
                    .status(Warehouse.WarehouseStatus.ACTIVE).build());
            Warehouse w3 = warehouseRepository.save(Warehouse.builder()
                    .name("West Hub").location("Los Angeles").capacity(1200)
                    .status(Warehouse.WarehouseStatus.ACTIVE).build());

            // Create products
            Product p1 = productRepository.save(Product.builder()
                    .name("Laptop Pro X1").sku("LAP-001").totalStock(500).build());
            Product p2 = productRepository.save(Product.builder()
                    .name("Wireless Mouse").sku("MOU-001").totalStock(1000).build());
            Product p3 = productRepository.save(Product.builder()
                    .name("USB-C Hub").sku("HUB-001").totalStock(300).build());

            // Assign inventory
            inventoryRepository.save(WarehouseInventory.builder()
                    .warehouse(w1).product(p1).availableQuantity(200).build());
            inventoryRepository.save(WarehouseInventory.builder()
                    .warehouse(w2).product(p1).availableQuantity(150).build());
            inventoryRepository.save(WarehouseInventory.builder()
                    .warehouse(w3).product(p1).availableQuantity(150).build());

            inventoryRepository.save(WarehouseInventory.builder()
                    .warehouse(w1).product(p2).availableQuantity(300).build());
            inventoryRepository.save(WarehouseInventory.builder()
                    .warehouse(w2).product(p2).availableQuantity(400).build());

            inventoryRepository.save(WarehouseInventory.builder()
                    .warehouse(w3).product(p3).availableQuantity(300).build());

            log.info("Sample data initialized: 3 warehouses, 3 products, 6 inventory records");
        };
    }
}
