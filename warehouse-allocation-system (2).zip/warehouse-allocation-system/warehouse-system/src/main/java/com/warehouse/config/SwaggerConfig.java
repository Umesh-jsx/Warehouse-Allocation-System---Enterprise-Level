package com.warehouse.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.*;
import org.springframework.context.annotation.*;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Warehouse Allocation System API")
                        .version("1.0.0")
                        .description("Enterprise Warehouse Allocation System - manages product distribution across multiple warehouses")
                        .contact(new Contact()
                                .name("Warehouse Team")
                                .email("support@warehouse.com")));
    }
}
