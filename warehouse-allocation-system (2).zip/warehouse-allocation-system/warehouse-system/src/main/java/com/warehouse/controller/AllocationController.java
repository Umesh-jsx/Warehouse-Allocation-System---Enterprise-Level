package com.warehouse.controller;

import com.warehouse.dto.*;
import com.warehouse.service.AllocationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/v1/allocations")
@RequiredArgsConstructor
@Tag(name = "Allocation", description = "Product allocation to warehouses")
public class AllocationController {

    private final AllocationService allocationService;

    @PostMapping
    @Operation(summary = "Allocate product to warehouse (auto-selects if warehouseId not provided)")
    public ResponseEntity<ApiResponse<AllocationDTO.Response>> allocate(
            @Valid @RequestBody AllocationDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(allocationService.allocate(request), "Allocation successful"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get allocation by ID")
    public ResponseEntity<ApiResponse<AllocationDTO.Response>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(allocationService.getAllocationById(id), "Allocation fetched"));
    }

    @GetMapping("/search")
    @Operation(summary = "Search allocations by product, warehouse, and date range (paginated)")
    public ResponseEntity<ApiResponse<Page<AllocationDTO.Response>>> search(
            @RequestParam(required = false) Long productId,
            @RequestParam(required = false) Long warehouseId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "allocatedAt") String sortBy) {

        Page<AllocationDTO.Response> result = allocationService
                .searchAllocations(productId, warehouseId, startDate, endDate, page, size, sortBy);
        return ResponseEntity.ok(ApiResponse.success(result, "Allocations fetched"));
    }
}
