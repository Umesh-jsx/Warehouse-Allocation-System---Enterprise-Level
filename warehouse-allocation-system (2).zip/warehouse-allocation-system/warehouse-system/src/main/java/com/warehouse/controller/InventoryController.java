package com.warehouse.controller;

import com.warehouse.dto.ApiResponse;
import com.warehouse.model.WarehouseInventory;
import com.warehouse.service.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
@Tag(name = "Inventory", description = "Warehouse inventory management")
public class InventoryController {

    private final InventoryService inventoryService;

    @PostMapping("/assign")
    @Operation(summary = "Assign product stock to a warehouse")
    public ResponseEntity<ApiResponse<WarehouseInventory>> assignInventory(
            @RequestParam Long warehouseId,
            @RequestParam Long productId,
            @RequestParam Integer quantity) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(
                        inventoryService.assignInventory(warehouseId, productId, quantity),
                        "Inventory assigned"));
    }

    @GetMapping("/warehouse/{warehouseId}")
    @Operation(summary = "Get inventory for a specific warehouse")
    public ResponseEntity<ApiResponse<List<WarehouseInventory>>> getByWarehouse(@PathVariable Long warehouseId) {
        return ResponseEntity.ok(ApiResponse.success(
                inventoryService.getInventoryByWarehouse(warehouseId), "Inventory fetched"));
    }

    @GetMapping("/product/{productId}")
    @Operation(summary = "Get inventory distribution for a product across all warehouses")
    public ResponseEntity<ApiResponse<List<WarehouseInventory>>> getByProduct(@PathVariable Long productId) {
        return ResponseEntity.ok(ApiResponse.success(
                inventoryService.getInventoryByProduct(productId), "Inventory fetched"));
    }
}
