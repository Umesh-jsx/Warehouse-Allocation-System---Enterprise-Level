package com.warehouse.controller;

import com.warehouse.dto.*;
import com.warehouse.service.StockTransferService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/stock-transfers")
@RequiredArgsConstructor
@Tag(name = "Stock Transfer", description = "Transfer stock between warehouses")
public class StockTransferController {

    private final StockTransferService stockTransferService;

    @PostMapping
    @Operation(summary = "Transfer stock between warehouses")
    public ResponseEntity<ApiResponse<StockTransferDTO.Response>> transfer(
            @Valid @RequestBody StockTransferDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(stockTransferService.transferStock(request), "Stock transferred"));
    }

    @GetMapping
    @Operation(summary = "Get all stock transfers")
    public ResponseEntity<ApiResponse<List<StockTransferDTO.Response>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(stockTransferService.getAllTransfers(), "Transfers fetched"));
    }

    @GetMapping("/product/{productId}")
    @Operation(summary = "Get transfers by product")
    public ResponseEntity<ApiResponse<List<StockTransferDTO.Response>>> getByProduct(@PathVariable Long productId) {
        return ResponseEntity.ok(ApiResponse.success(
                stockTransferService.getTransfersByProduct(productId), "Transfers fetched"));
    }
}
