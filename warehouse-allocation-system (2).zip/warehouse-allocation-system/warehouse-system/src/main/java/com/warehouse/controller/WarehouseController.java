package com.warehouse.controller;

import com.warehouse.dto.*;
import com.warehouse.service.WarehouseService;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/warehouses")
@RequiredArgsConstructor
@Tag(name = "Warehouse", description = "Warehouse CRUD and lifecycle management")
public class WarehouseController {

    private final WarehouseService warehouseService;

    @PostMapping
    @Operation(summary = "Create a new warehouse")
    public ResponseEntity<ApiResponse<WarehouseDTO.Response>> create(
            @Valid @RequestBody WarehouseDTO.Request request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(warehouseService.createWarehouse(request), "Warehouse created"));
    }

    @GetMapping
    @Operation(summary = "Get all active warehouses")
    public ResponseEntity<ApiResponse<List<WarehouseDTO.Response>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(warehouseService.getAllWarehouses(), "Warehouses fetched"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get warehouse by ID")
    public ResponseEntity<ApiResponse<WarehouseDTO.Response>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(warehouseService.getWarehouseById(id), "Warehouse fetched"));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update warehouse details")
    public ResponseEntity<ApiResponse<WarehouseDTO.Response>> update(
            @PathVariable Long id,
            @Valid @RequestBody WarehouseDTO.Request request) {
        return ResponseEntity.ok(ApiResponse.success(warehouseService.updateWarehouse(id, request), "Warehouse updated"));
    }

    @PatchMapping("/{id}/activate")
    @Operation(summary = "Activate a warehouse")
    public ResponseEntity<ApiResponse<Void>> activate(@PathVariable Long id) {
        warehouseService.activateWarehouse(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Warehouse activated"));
    }

    @PatchMapping("/{id}/deactivate")
    @Operation(summary = "Deactivate a warehouse")
    public ResponseEntity<ApiResponse<Void>> deactivate(@PathVariable Long id) {
        warehouseService.deactivateWarehouse(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Warehouse deactivated"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Soft delete a warehouse")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        warehouseService.softDeleteWarehouse(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Warehouse deleted"));
    }
}
