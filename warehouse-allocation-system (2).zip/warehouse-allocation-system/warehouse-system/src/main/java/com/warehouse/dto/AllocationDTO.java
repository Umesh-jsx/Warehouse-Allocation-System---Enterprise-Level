package com.warehouse.dto;

import com.warehouse.model.Allocation.AllocationStatus;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class AllocationDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {
        @NotNull(message = "Product ID is required")
        private Long productId;

        // Optional: if null, system auto-selects warehouse
        private Long warehouseId;

        @NotNull(message = "Quantity is required")
        @Min(value = 1, message = "Quantity must be at least 1")
        private Integer quantity;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private Long productId;
        private String productName;
        private Long warehouseId;
        private String warehouseName;
        private Integer quantity;
        private LocalDateTime allocatedAt;
        private AllocationStatus status;
    }
}
