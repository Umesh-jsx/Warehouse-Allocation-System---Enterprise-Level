package com.warehouse.dto;

import jakarta.validation.constraints.*;
import lombok.*;

public class ProductDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {
        @NotBlank(message = "Product name is required")
        private String name;

        @NotBlank(message = "SKU is required")
        private String sku;

        @NotNull(message = "Total stock is required")
        @Min(value = 0, message = "Total stock cannot be negative")
        private Integer totalStock;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private String name;
        private String sku;
        private Integer totalStock;
    }
}
