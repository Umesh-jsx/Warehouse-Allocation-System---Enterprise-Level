package com.warehouse.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class StockTransferDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {
        @NotNull(message = "Source warehouse ID is required")
        private Long sourceWarehouseId;

        @NotNull(message = "Target warehouse ID is required")
        private Long targetWarehouseId;

        @NotNull(message = "Product ID is required")
        private Long productId;

        @NotNull(message = "Quantity is required")
        @Min(value = 1, message = "Quantity must be at least 1")
        private Integer quantity;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private Long sourceWarehouseId;
        private String sourceWarehouseName;
        private Long targetWarehouseId;
        private String targetWarehouseName;
        private Long productId;
        private String productName;
        private Integer quantity;
        private LocalDateTime transferDate;
    }
}
