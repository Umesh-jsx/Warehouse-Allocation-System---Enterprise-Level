package com.warehouse.dto;

import com.warehouse.model.Warehouse.WarehouseStatus;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDateTime;

public class WarehouseDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Request {
        @NotBlank(message = "Warehouse name is required")
        private String name;

        @NotBlank(message = "Location is required")
        private String location;

        @NotNull(message = "Capacity is required")
        @Min(value = 1, message = "Capacity must be at least 1")
        private Integer capacity;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private String name;
        private String location;
        private Integer capacity;
        private WarehouseStatus status;
        private LocalDateTime createdAt;
    }
}
