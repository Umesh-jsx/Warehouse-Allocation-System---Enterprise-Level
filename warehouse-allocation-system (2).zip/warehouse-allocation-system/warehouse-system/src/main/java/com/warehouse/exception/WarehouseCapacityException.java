package com.warehouse.exception;

public class WarehouseCapacityException extends RuntimeException {
    public WarehouseCapacityException(String message) {
        super(message);
    }
}
