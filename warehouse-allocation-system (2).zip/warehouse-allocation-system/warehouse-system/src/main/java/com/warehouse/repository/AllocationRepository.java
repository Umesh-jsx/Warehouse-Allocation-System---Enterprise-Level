package com.warehouse.repository;

import com.warehouse.model.Allocation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;

@Repository
public interface AllocationRepository extends JpaRepository<Allocation, Long> {

    Page<Allocation> findByProductId(Long productId, Pageable pageable);

    Page<Allocation> findByWarehouseId(Long warehouseId, Pageable pageable);

    @Query("SELECT a FROM Allocation a WHERE " +
           "(:productId IS NULL OR a.product.id = :productId) AND " +
           "(:warehouseId IS NULL OR a.warehouse.id = :warehouseId) AND " +
           "(:startDate IS NULL OR a.allocatedAt >= :startDate) AND " +
           "(:endDate IS NULL OR a.allocatedAt <= :endDate)")
    Page<Allocation> searchAllocations(
            @Param("productId") Long productId,
            @Param("warehouseId") Long warehouseId,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate,
            Pageable pageable);
}
