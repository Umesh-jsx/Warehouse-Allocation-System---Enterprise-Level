package com.warehouse.repository;

import com.warehouse.model.StockTransfer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface StockTransferRepository extends JpaRepository<StockTransfer, Long> {
    List<StockTransfer> findBySourceWarehouseId(Long sourceWarehouseId);
    List<StockTransfer> findByTargetWarehouseId(Long targetWarehouseId);
    List<StockTransfer> findByProductId(Long productId);
}
