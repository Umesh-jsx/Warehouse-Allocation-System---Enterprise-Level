package com.warehouse.repository;

import com.warehouse.model.WarehouseInventory;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface WarehouseInventoryRepository extends JpaRepository<WarehouseInventory, Long> {

    Optional<WarehouseInventory> findByWarehouseIdAndProductId(Long warehouseId, Long productId);

    List<WarehouseInventory> findByProductId(Long productId);

    List<WarehouseInventory> findByWarehouseId(Long warehouseId);

    // Pessimistic lock for concurrent access
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT wi FROM WarehouseInventory wi WHERE wi.warehouse.id = :warehouseId AND wi.product.id = :productId")
    Optional<WarehouseInventory> findByWarehouseAndProductWithLock(
            @Param("warehouseId") Long warehouseId,
            @Param("productId") Long productId);

    // Find warehouse with most available stock for auto-selection
    @Query("SELECT wi FROM WarehouseInventory wi " +
           "JOIN wi.warehouse w " +
           "WHERE wi.product.id = :productId " +
           "AND wi.availableQuantity >= :quantity " +
           "AND w.status = 'ACTIVE' " +
           "AND w.deleted = false " +
           "ORDER BY wi.availableQuantity DESC")
    List<WarehouseInventory> findAvailableInventoryForProduct(
            @Param("productId") Long productId,
            @Param("quantity") Integer quantity);
}
