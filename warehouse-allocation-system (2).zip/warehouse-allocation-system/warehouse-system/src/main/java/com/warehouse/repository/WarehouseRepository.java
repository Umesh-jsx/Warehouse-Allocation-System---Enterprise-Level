package com.warehouse.repository;

import com.warehouse.model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {

    List<Warehouse> findByDeletedFalse();

    Optional<Warehouse> findByIdAndDeletedFalse(Long id);

    List<Warehouse> findByStatusAndDeletedFalse(Warehouse.WarehouseStatus status);
}
