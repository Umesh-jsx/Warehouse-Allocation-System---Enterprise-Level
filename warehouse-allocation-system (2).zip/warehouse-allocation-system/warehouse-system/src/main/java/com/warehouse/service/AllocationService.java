package com.warehouse.service;

import com.warehouse.dto.AllocationDTO;
import com.warehouse.exception.*;
import com.warehouse.model.*;
import com.warehouse.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AllocationService {

    private final AllocationRepository allocationRepository;
    private final WarehouseInventoryRepository inventoryRepository;
    private final ProductService productService;
    private final WarehouseService warehouseService;

    /**
     * Core allocation workflow:
     * 1. Validate product
     * 2. Auto-select warehouse OR use provided warehouseId
     * 3. Lock inventory record (concurrent safety)
     * 4. Validate capacity & stock
     * 5. Deduct stock, save allocation record
     */
    @Transactional
    public AllocationDTO.Response allocate(AllocationDTO.Request request) {
        log.info("Allocation request - Product: {}, Quantity: {}", request.getProductId(), request.getQuantity());

        // Step 1: Validate product exists
        Product product = productService.findById(request.getProductId());

        // Step 2: Determine warehouse
        WarehouseInventory inventory;
        if (request.getWarehouseId() != null) {
            // Specific warehouse requested
            Warehouse warehouse = warehouseService.findActiveById(request.getWarehouseId());
            if (warehouse.getStatus() == Warehouse.WarehouseStatus.INACTIVE) {
                throw new WarehouseCapacityException("Warehouse is inactive: " + warehouse.getId());
            }
            inventory = inventoryRepository
                    .findByWarehouseAndProductWithLock(request.getWarehouseId(), request.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "No inventory found for product in warehouse " + request.getWarehouseId()));
        } else {
            // Auto-select: find warehouse with most available stock
            List<WarehouseInventory> available = inventoryRepository
                    .findAvailableInventoryForProduct(request.getProductId(), request.getQuantity());
            if (available.isEmpty()) {
                throw new InsufficientStockException(
                        "No warehouse has sufficient stock for product " + request.getProductId()
                        + " with quantity " + request.getQuantity());
            }
            inventory = available.get(0);
        }

        // Step 3 & 4: Validate stock
        if (inventory.getAvailableQuantity() < request.getQuantity()) {
            throw new InsufficientStockException(
                    "Insufficient stock. Available: " + inventory.getAvailableQuantity()
                    + ", Requested: " + request.getQuantity());
        }

        // Step 5: Deduct and save
        inventory.setAvailableQuantity(inventory.getAvailableQuantity() - request.getQuantity());
        inventoryRepository.save(inventory);

        Allocation allocation = Allocation.builder()
                .product(product)
                .warehouse(inventory.getWarehouse())
                .quantity(request.getQuantity())
                .status(Allocation.AllocationStatus.COMPLETED)
                .build();
        allocation = allocationRepository.save(allocation);

        log.info("Allocation completed - ID: {}, Warehouse: {}", allocation.getId(), inventory.getWarehouse().getName());
        return toResponse(allocation);
    }

    @Transactional(readOnly = true)
    public Page<AllocationDTO.Response> searchAllocations(
            Long productId, Long warehouseId,
            LocalDateTime startDate, LocalDateTime endDate,
            int page, int size, String sortBy) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy).descending());
        return allocationRepository
                .searchAllocations(productId, warehouseId, startDate, endDate, pageable)
                .map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public AllocationDTO.Response getAllocationById(Long id) {
        return toResponse(allocationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Allocation not found: " + id)));
    }

    private AllocationDTO.Response toResponse(Allocation a) {
        return AllocationDTO.Response.builder()
                .id(a.getId())
                .productId(a.getProduct().getId())
                .productName(a.getProduct().getName())
                .warehouseId(a.getWarehouse().getId())
                .warehouseName(a.getWarehouse().getName())
                .quantity(a.getQuantity())
                .allocatedAt(a.getAllocatedAt())
                .status(a.getStatus())
                .build();
    }
}
