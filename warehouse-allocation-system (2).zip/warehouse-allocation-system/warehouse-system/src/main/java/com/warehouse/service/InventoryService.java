package com.warehouse.service;

import com.warehouse.exception.ResourceNotFoundException;
import com.warehouse.model.*;
import com.warehouse.repository.WarehouseInventoryRepository;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class InventoryService {

    private final WarehouseInventoryRepository inventoryRepository;
    private final WarehouseService warehouseService;
    private final ProductService productService;

    /**
     * Assign product stock to a specific warehouse
     */
    @Transactional
    public WarehouseInventory assignInventory(Long warehouseId, Long productId, Integer quantity) {
        log.info("Assigning inventory - Warehouse: {}, Product: {}, Qty: {}", warehouseId, productId, quantity);

        Warehouse warehouse = warehouseService.findActiveById(warehouseId);
        Product product = productService.findById(productId);

        // Check capacity
        int currentTotal = inventoryRepository.findByWarehouseId(warehouseId)
                .stream().mapToInt(WarehouseInventory::getAvailableQuantity).sum();
        if (currentTotal + quantity > warehouse.getCapacity()) {
            throw new RuntimeException("Warehouse capacity exceeded. Capacity: "
                    + warehouse.getCapacity() + ", Current: " + currentTotal + ", Adding: " + quantity);
        }

        WarehouseInventory inventory = inventoryRepository
                .findByWarehouseIdAndProductId(warehouseId, productId)
                .orElse(WarehouseInventory.builder()
                        .warehouse(warehouse)
                        .product(product)
                        .availableQuantity(0)
                        .build());

        inventory.setAvailableQuantity(inventory.getAvailableQuantity() + quantity);
        return inventoryRepository.save(inventory);
    }

    @Transactional(readOnly = true)
    public List<WarehouseInventory> getInventoryByWarehouse(Long warehouseId) {
        warehouseService.findActiveById(warehouseId); // validate
        return inventoryRepository.findByWarehouseId(warehouseId);
    }

    @Transactional(readOnly = true)
    public List<WarehouseInventory> getInventoryByProduct(Long productId) {
        productService.findById(productId); // validate
        return inventoryRepository.findByProductId(productId);
    }

    @Data
    @AllArgsConstructor
    public static class InventoryResponse {
        private Long warehouseId;
        private String warehouseName;
        private Long productId;
        private String productName;
        private Integer availableQuantity;
    }
}
