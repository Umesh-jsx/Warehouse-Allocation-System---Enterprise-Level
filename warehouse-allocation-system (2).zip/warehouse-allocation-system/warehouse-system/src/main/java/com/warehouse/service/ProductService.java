package com.warehouse.service;

import com.warehouse.dto.ProductDTO;
import com.warehouse.exception.ResourceNotFoundException;
import com.warehouse.model.Product;
import com.warehouse.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductService {

    private final ProductRepository productRepository;

    @Transactional
    public ProductDTO.Response createProduct(ProductDTO.Request request) {
        log.info("Creating product with SKU: {}", request.getSku());
        if (productRepository.existsBySku(request.getSku())) {
            throw new IllegalArgumentException("Product with SKU already exists: " + request.getSku());
        }
        Product product = Product.builder()
                .name(request.getName())
                .sku(request.getSku())
                .totalStock(request.getTotalStock())
                .build();
        return toResponse(productRepository.save(product));
    }

    @Transactional(readOnly = true)
    public List<ProductDTO.Response> getAllProducts() {
        return productRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProductDTO.Response getProductById(Long id) {
        return toResponse(findById(id));
    }

    @Transactional
    public ProductDTO.Response updateProduct(Long id, ProductDTO.Request request) {
        Product product = findById(id);
        product.setName(request.getName());
        product.setTotalStock(request.getTotalStock());
        return toResponse(productRepository.save(product));
    }

    @Transactional
    public void deleteProduct(Long id) {
        Product product = findById(id);
        productRepository.delete(product);
    }

    // Package-private for use in other services
    Product findById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
    }

    private ProductDTO.Response toResponse(Product p) {
        return ProductDTO.Response.builder()
                .id(p.getId())
                .name(p.getName())
                .sku(p.getSku())
                .totalStock(p.getTotalStock())
                .build();
    }
}
