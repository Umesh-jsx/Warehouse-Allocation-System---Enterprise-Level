package com.warehouse.service;

import com.warehouse.dto.StockTransferDTO;
import com.warehouse.exception.*;
import com.warehouse.model.*;
import com.warehouse.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class StockTransferService {

    private final StockTransferRepository stockTransferRepository;
    private final WarehouseInventoryRepository inventoryRepository;
    private final ProductService productService;
    private final WarehouseService warehouseService;

    @Transactional
    public StockTransferDTO.Response transferStock(StockTransferDTO.Request request) {
        log.info("Stock transfer: {} -> {}, Product: {}, Qty: {}",
                request.getSourceWarehouseId(), request.getTargetWarehouseId(),
                request.getProductId(), request.getQuantity());

        if (request.getSourceWarehouseId().equals(request.getTargetWarehouseId())) {
            throw new IllegalArgumentException("Source and target warehouse cannot be the same");
        }

        Product product = productService.findById(request.getProductId());
        Warehouse source = warehouseService.findActiveById(request.getSourceWarehouseId());
        Warehouse target = warehouseService.findActiveById(request.getTargetWarehouseId());

        // Lock source inventory
        WarehouseInventory sourceInv = inventoryRepository
                .findByWarehouseAndProductWithLock(source.getId(), product.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No inventory in source warehouse for product " + product.getId()));

        // Validate stock
        if (sourceInv.getAvailableQuantity() < request.getQuantity()) {
            throw new InsufficientStockException(
                    "Insufficient stock in source warehouse. Available: " + sourceInv.getAvailableQuantity());
        }

        // Validate target capacity
        int currentTargetTotal = inventoryRepository.findByWarehouseId(target.getId())
                .stream().mapToInt(WarehouseInventory::getAvailableQuantity).sum();
        if (currentTargetTotal + request.getQuantity() > target.getCapacity()) {
            throw new WarehouseCapacityException("Target warehouse capacity exceeded");
        }

        // Deduct from source
        sourceInv.setAvailableQuantity(sourceInv.getAvailableQuantity() - request.getQuantity());
        inventoryRepository.save(sourceInv);

        // Add to target (create if not exists)
        WarehouseInventory targetInv = inventoryRepository
                .findByWarehouseIdAndProductId(target.getId(), product.getId())
                .orElse(WarehouseInventory.builder()
                        .warehouse(target)
                        .product(product)
                        .availableQuantity(0)
                        .build());
        targetInv.setAvailableQuantity(targetInv.getAvailableQuantity() + request.getQuantity());
        inventoryRepository.save(targetInv);

        // Record transfer
        StockTransfer transfer = StockTransfer.builder()
                .sourceWarehouse(source)
                .targetWarehouse(target)
                .product(product)
                .quantity(request.getQuantity())
                .build();
        transfer = stockTransferRepository.save(transfer);

        log.info("Transfer completed, ID: {}", transfer.getId());
        return toResponse(transfer);
    }

    @Transactional(readOnly = true)
    public List<StockTransferDTO.Response> getAllTransfers() {
        return stockTransferRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<StockTransferDTO.Response> getTransfersByProduct(Long productId) {
        return stockTransferRepository.findByProductId(productId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    private StockTransferDTO.Response toResponse(StockTransfer t) {
        return StockTransferDTO.Response.builder()
                .id(t.getId())
                .sourceWarehouseId(t.getSourceWarehouse().getId())
                .sourceWarehouseName(t.getSourceWarehouse().getName())
                .targetWarehouseId(t.getTargetWarehouse().getId())
                .targetWarehouseName(t.getTargetWarehouse().getName())
                .productId(t.getProduct().getId())
                .productName(t.getProduct().getName())
                .quantity(t.getQuantity())
                .transferDate(t.getTransferDate())
                .build();
    }
}
