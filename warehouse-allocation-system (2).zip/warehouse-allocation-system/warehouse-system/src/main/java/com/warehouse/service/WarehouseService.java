package com.warehouse.service;

import com.warehouse.dto.WarehouseDTO;
import com.warehouse.exception.ResourceNotFoundException;
import com.warehouse.model.Warehouse;
import com.warehouse.model.Warehouse.WarehouseStatus;
import com.warehouse.repository.WarehouseRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class WarehouseService {

    private final WarehouseRepository warehouseRepository;

    @Transactional
    public WarehouseDTO.Response createWarehouse(WarehouseDTO.Request request) {
        log.info("Creating warehouse: {}", request.getName());
        Warehouse warehouse = Warehouse.builder()
                .name(request.getName())
                .location(request.getLocation())
                .capacity(request.getCapacity())
                .status(WarehouseStatus.ACTIVE)
                .build();
        return toResponse(warehouseRepository.save(warehouse));
    }

    @Transactional(readOnly = true)
    public List<WarehouseDTO.Response> getAllWarehouses() {
        return warehouseRepository.findByDeletedFalse()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public WarehouseDTO.Response getWarehouseById(Long id) {
        return toResponse(findActiveById(id));
    }

    @Transactional
    public WarehouseDTO.Response updateWarehouse(Long id, WarehouseDTO.Request request) {
        log.info("Updating warehouse id: {}", id);
        Warehouse warehouse = findActiveById(id);
        warehouse.setName(request.getName());
        warehouse.setLocation(request.getLocation());
        warehouse.setCapacity(request.getCapacity());
        return toResponse(warehouseRepository.save(warehouse));
    }

    @Transactional
    public void activateWarehouse(Long id) {
        log.info("Activating warehouse id: {}", id);
        Warehouse warehouse = findActiveById(id);
        warehouse.setStatus(WarehouseStatus.ACTIVE);
        warehouseRepository.save(warehouse);
    }

    @Transactional
    public void deactivateWarehouse(Long id) {
        log.info("Deactivating warehouse id: {}", id);
        Warehouse warehouse = findActiveById(id);
        warehouse.setStatus(WarehouseStatus.INACTIVE);
        warehouseRepository.save(warehouse);
    }

    @Transactional
    public void softDeleteWarehouse(Long id) {
        log.info("Soft deleting warehouse id: {}", id);
        Warehouse warehouse = findActiveById(id);
        warehouse.setDeleted(true);
        warehouseRepository.save(warehouse);
    }

    // Package-private for use in other services
    Warehouse findActiveById(Long id) {
        return warehouseRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with id: " + id));
    }

    private WarehouseDTO.Response toResponse(Warehouse w) {
        return WarehouseDTO.Response.builder()
                .id(w.getId())
                .name(w.getName())
                .location(w.getLocation())
                .capacity(w.getCapacity())
                .status(w.getStatus())
                .createdAt(w.getCreatedAt())
                .build();
    }
}
