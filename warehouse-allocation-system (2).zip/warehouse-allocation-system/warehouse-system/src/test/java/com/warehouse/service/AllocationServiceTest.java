package com.warehouse.service;

import com.warehouse.dto.AllocationDTO;
import com.warehouse.exception.*;
import com.warehouse.model.*;
import com.warehouse.repository.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AllocationServiceTest {

    @Mock private AllocationRepository allocationRepository;
    @Mock private WarehouseInventoryRepository inventoryRepository;
    @Mock private ProductService productService;
    @Mock private WarehouseService warehouseService;

    @InjectMocks private AllocationService allocationService;

    private Product product;
    private Warehouse warehouse;
    private WarehouseInventory inventory;

    @BeforeEach
    void setUp() {
        product = Product.builder().id(1L).name("Laptop").sku("LAP-001").totalStock(500).build();
        warehouse = Warehouse.builder().id(1L).name("North Hub")
                .status(Warehouse.WarehouseStatus.ACTIVE).capacity(1000).build();
        inventory = WarehouseInventory.builder()
                .id(1L).warehouse(warehouse).product(product).availableQuantity(100).build();
    }

    @Test
    @DisplayName("Should allocate successfully with specific warehouse")
    void allocate_withSpecificWarehouse_success() {
        AllocationDTO.Request request = new AllocationDTO.Request(1L, 1L, 50);
        Allocation saved = Allocation.builder().id(1L).product(product)
                .warehouse(warehouse).quantity(50)
                .status(Allocation.AllocationStatus.COMPLETED).build();

        when(productService.findById(1L)).thenReturn(product);
        when(warehouseService.findActiveById(1L)).thenReturn(warehouse);
        when(inventoryRepository.findByWarehouseAndProductWithLock(1L, 1L))
                .thenReturn(Optional.of(inventory));
        when(inventoryRepository.save(any())).thenReturn(inventory);
        when(allocationRepository.save(any())).thenReturn(saved);

        AllocationDTO.Response response = allocationService.allocate(request);

        assertNotNull(response);
        assertEquals(1L, response.getId());
        assertEquals(50, response.getQuantity());
        verify(inventoryRepository).save(argThat(inv -> inv.getAvailableQuantity() == 50));
    }

    @Test
    @DisplayName("Should auto-select warehouse when warehouseId is null")
    void allocate_autoSelectWarehouse_success() {
        AllocationDTO.Request request = new AllocationDTO.Request(1L, null, 30);
        Allocation saved = Allocation.builder().id(2L).product(product)
                .warehouse(warehouse).quantity(30)
                .status(Allocation.AllocationStatus.COMPLETED).build();

        when(productService.findById(1L)).thenReturn(product);
        when(inventoryRepository.findAvailableInventoryForProduct(1L, 30))
                .thenReturn(List.of(inventory));
        when(inventoryRepository.save(any())).thenReturn(inventory);
        when(allocationRepository.save(any())).thenReturn(saved);

        AllocationDTO.Response response = allocationService.allocate(request);

        assertNotNull(response);
        assertEquals(30, response.getQuantity());
    }

    @Test
    @DisplayName("Should throw InsufficientStockException when stock is not enough")
    void allocate_insufficientStock_throwsException() {
        AllocationDTO.Request request = new AllocationDTO.Request(1L, 1L, 200);

        when(productService.findById(1L)).thenReturn(product);
        when(warehouseService.findActiveById(1L)).thenReturn(warehouse);
        when(inventoryRepository.findByWarehouseAndProductWithLock(1L, 1L))
                .thenReturn(Optional.of(inventory)); // only 100 available

        assertThrows(InsufficientStockException.class, () -> allocationService.allocate(request));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when product not found")
    void allocate_productNotFound_throwsException() {
        AllocationDTO.Request request = new AllocationDTO.Request(99L, 1L, 10);

        when(productService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Product not found"));

        assertThrows(ResourceNotFoundException.class, () -> allocationService.allocate(request));
    }

    @Test
    @DisplayName("Should throw InsufficientStockException when no warehouse has stock for auto-selection")
    void allocate_noWarehouseAvailable_throwsException() {
        AllocationDTO.Request request = new AllocationDTO.Request(1L, null, 500);

        when(productService.findById(1L)).thenReturn(product);
        when(inventoryRepository.findAvailableInventoryForProduct(1L, 500))
                .thenReturn(Collections.emptyList());

        assertThrows(InsufficientStockException.class, () -> allocationService.allocate(request));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when inventory not found for specific warehouse")
    void allocate_inventoryNotFoundInWarehouse_throwsException() {
        AllocationDTO.Request request = new AllocationDTO.Request(1L, 1L, 10);

        when(productService.findById(1L)).thenReturn(product);
        when(warehouseService.findActiveById(1L)).thenReturn(warehouse);
        when(inventoryRepository.findByWarehouseAndProductWithLock(1L, 1L))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> allocationService.allocate(request));
    }
}
