package com.warehouse.service;

import com.warehouse.dto.StockTransferDTO;
import com.warehouse.exception.*;
import com.warehouse.model.*;
import com.warehouse.repository.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StockTransferServiceTest {

    @Mock private StockTransferRepository stockTransferRepository;
    @Mock private WarehouseInventoryRepository inventoryRepository;
    @Mock private ProductService productService;
    @Mock private WarehouseService warehouseService;

    @InjectMocks private StockTransferService stockTransferService;

    private Product product;
    private Warehouse source, target;
    private WarehouseInventory sourceInv;

    @BeforeEach
    void setUp() {
        product = Product.builder().id(1L).name("Laptop").sku("LAP-001").totalStock(500).build();
        source = Warehouse.builder().id(1L).name("North Hub").capacity(1000)
                .status(Warehouse.WarehouseStatus.ACTIVE).build();
        target = Warehouse.builder().id(2L).name("South Hub").capacity(800)
                .status(Warehouse.WarehouseStatus.ACTIVE).build();
        sourceInv = WarehouseInventory.builder()
                .id(1L).warehouse(source).product(product).availableQuantity(200).build();
    }

    @Test
    @DisplayName("Should transfer stock successfully")
    void transferStock_success() {
        StockTransferDTO.Request request = new StockTransferDTO.Request(1L, 2L, 1L, 50);
        StockTransfer saved = StockTransfer.builder().id(1L)
                .sourceWarehouse(source).targetWarehouse(target)
                .product(product).quantity(50).build();

        when(productService.findById(1L)).thenReturn(product);
        when(warehouseService.findActiveById(1L)).thenReturn(source);
        when(warehouseService.findActiveById(2L)).thenReturn(target);
        when(inventoryRepository.findByWarehouseAndProductWithLock(1L, 1L))
                .thenReturn(Optional.of(sourceInv));
        when(inventoryRepository.findByWarehouseId(2L)).thenReturn(Collections.emptyList());
        when(inventoryRepository.findByWarehouseIdAndProductId(2L, 1L)).thenReturn(Optional.empty());
        when(inventoryRepository.save(any())).thenReturn(sourceInv);
        when(stockTransferRepository.save(any())).thenReturn(saved);

        StockTransferDTO.Response response = stockTransferService.transferStock(request);

        assertNotNull(response);
        assertEquals(50, response.getQuantity());
        assertEquals("North Hub", response.getSourceWarehouseName());
    }

    @Test
    @DisplayName("Should throw exception when source and target are the same")
    void transferStock_sameWarehouse_throwsException() {
        StockTransferDTO.Request request = new StockTransferDTO.Request(1L, 1L, 1L, 50);
        assertThrows(IllegalArgumentException.class, () -> stockTransferService.transferStock(request));
    }

    @Test
    @DisplayName("Should throw InsufficientStockException when source has insufficient stock")
    void transferStock_insufficientStock_throwsException() {
        StockTransferDTO.Request request = new StockTransferDTO.Request(1L, 2L, 1L, 500);
        sourceInv.setAvailableQuantity(100);

        when(productService.findById(1L)).thenReturn(product);
        when(warehouseService.findActiveById(1L)).thenReturn(source);
        when(warehouseService.findActiveById(2L)).thenReturn(target);
        when(inventoryRepository.findByWarehouseAndProductWithLock(1L, 1L))
                .thenReturn(Optional.of(sourceInv));

        assertThrows(InsufficientStockException.class, () -> stockTransferService.transferStock(request));
    }
}
