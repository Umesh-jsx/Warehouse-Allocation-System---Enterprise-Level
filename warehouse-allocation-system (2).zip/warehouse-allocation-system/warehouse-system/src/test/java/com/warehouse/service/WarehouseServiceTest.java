package com.warehouse.service;

import com.warehouse.dto.WarehouseDTO;
import com.warehouse.exception.ResourceNotFoundException;
import com.warehouse.model.Warehouse;
import com.warehouse.repository.WarehouseRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class WarehouseServiceTest {

    @Mock private WarehouseRepository warehouseRepository;
    @InjectMocks private WarehouseService warehouseService;

    private Warehouse warehouse;

    @BeforeEach
    void setUp() {
        warehouse = Warehouse.builder()
                .id(1L).name("North Hub").location("New York")
                .capacity(1000).status(Warehouse.WarehouseStatus.ACTIVE).deleted(false).build();
    }

    @Test
    @DisplayName("Should create warehouse successfully")
    void createWarehouse_success() {
        WarehouseDTO.Request request = new WarehouseDTO.Request("North Hub", "New York", 1000);
        when(warehouseRepository.save(any())).thenReturn(warehouse);

        WarehouseDTO.Response response = warehouseService.createWarehouse(request);

        assertNotNull(response);
        assertEquals("North Hub", response.getName());
        assertEquals("New York", response.getLocation());
        assertEquals(1000, response.getCapacity());
    }

    @Test
    @DisplayName("Should return all non-deleted warehouses")
    void getAllWarehouses_success() {
        when(warehouseRepository.findByDeletedFalse()).thenReturn(List.of(warehouse));

        List<WarehouseDTO.Response> result = warehouseService.getAllWarehouses();

        assertEquals(1, result.size());
        assertEquals("North Hub", result.get(0).getName());
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when warehouse not found")
    void getWarehouseById_notFound_throwsException() {
        when(warehouseRepository.findByIdAndDeletedFalse(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> warehouseService.getWarehouseById(99L));
    }

    @Test
    @DisplayName("Should soft delete warehouse")
    void softDeleteWarehouse_success() {
        when(warehouseRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(warehouse));
        when(warehouseRepository.save(any())).thenReturn(warehouse);

        assertDoesNotThrow(() -> warehouseService.softDeleteWarehouse(1L));
        verify(warehouseRepository).save(argThat(w -> w.isDeleted()));
    }

    @Test
    @DisplayName("Should deactivate warehouse")
    void deactivateWarehouse_success() {
        when(warehouseRepository.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(warehouse));
        when(warehouseRepository.save(any())).thenReturn(warehouse);

        assertDoesNotThrow(() -> warehouseService.deactivateWarehouse(1L));
        verify(warehouseRepository).save(argThat(w -> w.getStatus() == Warehouse.WarehouseStatus.INACTIVE));
    }
}
